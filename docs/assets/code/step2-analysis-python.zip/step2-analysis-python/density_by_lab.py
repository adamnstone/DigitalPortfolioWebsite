import pandas as pd
import pickle, json
import networkx as nx
import matplotlib.pyplot as plt

lab_names_urls = ['aachen', 'aalto', 'agrilab', 'akgec', 'akureyri', 'algarve', 'bahrain', 'bangalore', 'barcelona', 'benfica', 'berytech', 'bhubaneswar', 'bhutan', 'boldseoul', 'bottrop', 'brighton', 'cept', 'chaihuo', 'chandigarh', 'charlotte', 'cidi', 'cit', 'ciudadmexico', 'cpcc', 'crunchlab', 'dassault', 'deusto', 'dhahran', 'digiscope', 'dilijan', 'ecae', 'echofab', 'ecostudio', 'egypt', 'energylab', 'esan', 'esne', 'fablabaachen', 'fablabaalto', 'fablabakgec', 'fablabamsterdam', 'fablabat3flo', 'fablabbahrain', 'fablabbeijing', 'fablabberytech', 'fablabbottrop', 'fablabbrighton', 'fablabcept', 'fablabcharlottelatin', 'fablabdassault', 'fablabdigiscope', 'fablabechofab', 'fablabecostudio', 'fablabegypt', 'fablaberfindergarden', 'fablabesan', 'fablabfacens', 'fablabfct', 'fablabgearbox', 'fablabincitefocus', 'fablabirbid', 'fablabisafjorour', 'fablabkamakura', 'fablabkamplintfort', 'fablabkhairpur', 'fablabkochi', 'fablabkromlaboro', 'fablablccc', 'fablableon', 'fablabmadridceu', 'fablabmexico', 'fablabodessa', 'fablabopendot', 'fablaboshanghai', 'fablaboulu', 'fablabpuebla', 'fablabreykjavik', 'fablabrwanda', 'fablabsantiago', 'fablabseoul', 'fablabseoulinnovation', 'fablabsiena', 'fablabsocom', 'fablabsorbonne', 'fablabspinderihallerne', 'fablabszoil', 'fablabtechworks', 'fablabtecsup', 'fablabtembisa', 'fablabtrivandrum', 'fablabuae', 'fablabulb', 'fablabutec', 'fablabvigyanasharm', 'fablabwgtn', 'fablabyachay', 'fablabyucatan', 'fablabzoi', 'falabdeusto', 'falabvestmannaeyjar', 'farmlabalgarve', 'fct', 'formshop', 'hkispace', 'ied', 'incitefocus', 'ingegno', 'inphb', 'insper', 'ioannina', 'irbid', 'isafjordur', 'jubail', 'kamakura', 'kamplintfort', 'kannai', 'kaust', 'keolab', 'khairpur', 'kitakagaya', 'kochi', 'lakazlab', 'lamachinerie', 'lccc', 'leon', 'libya', 'lima', 'napoli', 'newcairo', 'ningbo', 'opendot', 'oshanghai', 'oulu', 'plusx', 'polytech', 'puebla', 'qbic', 'reykjavik', 'riidl', 'rwanda', 'santachiara', 'sedi', 'seoul', 'seoulinnovation', 'singapore', 'sorbonne', 'stjude', 'szoil', 'taipei', 'talents', 'techworks', 'tecsup', 'tecsupaqp', 'tianhelab', 'tinkerers', 'trivandrum', 'twarda', 'uae', 'ucal', 'ucontinental', 'uemadrid', 'ulb', 'ulima', 'utec', 'vancouver', 'vestmannaeyjar', 'vigyanashram', 'waag', 'wheaton', 'winam', 'yucatan', 'zoi']

MIN_STUDENTS = 5

labs_by_continent = {
    "vigyanashram":"Asia", # India
    "oulu":"Europe", # Finland
    "kamplintfort":"Europe", # Germany
    "charlotte":"North America", # USA (Assumed)
    "lccc":"North America", # USA (Assumed)
    "bahrain":"Asia", # Bahrain
    "uae":"Asia", # United Arab Emirates
    "libya":"Africa", # Libya
    "techworks":"North America", # USA (Assumed)
    "newcairo":"Africa", # Egypt
    "egypt":"Africa", # Egypt
    "lakazlab":"Africa", # Mauritius (Assumed)
    "tecsup":"South America", # Peru
    "wheaton":"North America", # USA (Assumed)
    "fablabuae":"Asia", # United Arab Emirates
    "qbic":"Asia", # Qatar (Assumed)
    "kochi":"Asia", # India
    "ied":"Europe", # Italy (Assumed)
    "fablabtrivandrum":"Asia", # India
    "fablabakgec":"Asia", # India
    "barcelona":"Europe", # Spain
    "fablabsorbonne":"Europe", # France
    "fablabcept":"Asia", # India
    "rwanda":"Africa", # Rwanda
    "leon":"Europe", # Spain (Assumed)
    "lamachinerie":"Europe", # France (Assumed)
    "fablabdigiscope":"Europe", # France (Assumed)
    "energylab":"Europe", # Denmark (Assumed)
    "akgec":"Asia", # India
    "irbid":"Asia", # Jordan
    "reykjavik":"Europe", # Iceland
    "sorbonne":"Europe", # France
    "incitefocus":"North America", # USA (Assumed)
    "puebla":"North America", # Mexico
    "tecsupaqp":"South America", # Peru
    "ucontinental":"South America", # Peru
    "fablabopendot":"Europe", # Italy
    "santachiara":"Europe", # Italy
    "fablabechofab":"North America", # Canada
    "zoi":"Asia", # China (Assumed)
    "cidi":"North America", # USA (Assumed)
    "dassault":"Europe", # France (Assumed)
    "stjude":"North America", # USA (Assumed)
    "aalto":"Europe", # Finland
    "fablabzoi":"Asia", # China (Assumed)
    "ecae":"Asia", # United Arab Emirates
    "fablabbahrain":"Asia", # Bahrain
    "khairpur":"Asia", # Pakistan
    "insper":"South America", # Brazil
    "trivandrum":"Asia", # India
    "inphb":"Africa", # Ivory Coast
    "digiscope":"Europe", # France (Assumed)
    "ulb":"Europe", # Belgium (Assumed)
    "lima":"South America", # Peru
    "fablabspinderihallerne":"Europe", # Denmark
    "fablabfct":"Europe", # Portugal (Assumed)
    "fct":"Africa", # Nigeria (Assumed)
    "opendot":"Europe", # Italy
    "fablabtecsup":"South America", # Peru
    "vancouver":"North America", # Canada
    "fablabbrighton":"Europe", # UK
    "akureyri":"Europe", # Iceland
    "yucatan":"North America", # Mexico
    "bhutan":"Asia", # Bhutan
    "fablabaachen":"Europe", # Germany
    "waag":"Europe", # Netherlands
    "echofab":"North America", # Canada
    "dilijan":"Asia", # Armenia
    "polytech":"Europe", # France (Assumed)
    "agrilab":"Asia", # Armenia
    "fablabsiena":"Europe", # Italy -- ChatGPT changed "fablabsiena" to "siena" -- corrected by hand
    "winam":"Africa", # Kenya (Assumed)
    "fablaboulu":"Europe", # Finland
    "fablabreykjavik":"Europe", # Iceland
    "kamakura":"Asia", # Japan
    "falabvestmannaeyjar":"Europe", # Iceland
    "singapore":"Asia", # Singapore
    "oshanghai":"Asia", # China
    "fablaboshanghai":"Asia", # China
    "fablabutec":"South America", # Peru
    "fablabodessa":"Europe", # Ukraine
    "esan":"South America", # Peru
    "fablabvigyanasharm":"Asia", # India
    "hkispace":"Asia", # Hong Kong
    "taipei":"Asia", # Taiwan
    "fablabmexico":"North America", # Mexico
    "ciudadmexico":"North America", # Mexico
    "aachen":"Europe", # Germany
    "fablabbottrop":"Europe", # Germany
    "fablabaalto":"Europe", # Finland
    "keolab":"Asia", # Japan (Assumed)
    "cpcc":"North America", # USA (Assumed)
    "fablabkamplintfort":"Europe", # Germany
    "ingegno":"Europe", # Italy (Assumed)
    "fablabkamakura":"Asia", # Japan
    "tinkerers":"Asia", # United Arab Emirates (Assumed)
    "cit":"Europe", # Ireland (Assumed)
    "utec":"South America", # Peru
    "fablabamsterdam":"Europe", # Netherlands
    "tianhelab":"Asia", # China (Assumed)
    "bhubaneswar":"Asia", # India
    "cept":"Asia", # India
    "fablabbeijing":"Asia", # China
    "talents":"Europe", # Germany (Assumed)
    "fablabyachay":"South America", # Ecuador
    "fablabdassault":"Europe", # France (Assumed)
    "ecostudio":"North America", # USA (Assumed)
    "fablabseoul":"Asia", # South Korea
    "kaust":"Asia", # Saudi Arabia
    "berytech":"Asia", # Lebanon
    "fablabpuebla":"North America", # Mexico
    "fablabrwanda":"Africa", # Rwanda
    "fablabesan":"South America", # Peru
    "fablabberytech":"Asia", # Lebanon
    "crunchlab":"Europe", # Portugal (Assumed)
    "ucal":"North America", # USA (Assumed)
    "vestmannaeyjar":"Europe", # Iceland
    "sedi":"Europe", # Italy (Assumed)
    "isafjordur":"Europe", # Iceland
    "fablabegypt":"Africa", # Egypt
    "szoil":"Asia", # China
    "formshop":"Asia", # China (Assumed)
    "fablabkochi":"Asia", # India
    "fablabincitefocus":"North America", # USA (Assumed)
    "kitakagaya":"Asia", # Japan
    "kannai":"Asia", # Japan
    "dhahran":"Asia", # Saudi Arabia
    "seoulinnovation":"Asia", # South Korea
    "ioannina":"Europe", # Greece
    "fablabyucatan":"North America", # Mexico
    "fablabirbid":"Asia", # Jordan
    "deusto":"Europe", # Spain
    "falabdeusto":"Europe", # Spain
    "riidl":"Asia", # India
    "bottrop":"Europe", # Germany
    "fablabisafjorour":"Europe", # Iceland
    "plusx":"Asia", # South Korea (Assumed)
    "fablaberfindergarden":"Europe", # Germany (Assumed)
    "uemadrid":"Europe", # Spain
    "fablabtembisa":"Africa", # South Africa
    "brighton":"Europe", # UK
    "fablabfacens":"South America", # Brazil
    "fablableon":"Europe", # Spain (Assumed)
    "fablabszoil":"Asia", # China
    "fablabgearbox":"Africa", # Kenya (Assumed)
    "farmlabalgarve":"Europe", # Portugal
    "algarve":"Europe", # Portugal
    "twarda":"Europe", # Poland (Assumed)
    "bangalore":"Asia", # India
    "fablabsantiago":"South America", # Chile
    "fablablccc":"North America", # USA (Assumed)
    "fablabcharlottelatin":"North America", # USA
    "fablabat3flo":"Europe", # Hungary (Assumed)
    "fablabecostudio":"North America", # USA (Assumed)
    "fablabsocom":"Asia", # China (Assumed)
    "boldseoul":"Asia", # South Korea
    "napoli":"Europe", # Italy
    "fablabkromlaboro":"Europe", # Slovenia (Assumed)
    "seoul":"Asia", # South Korea
    "fablabtechworks":"North America", # USA (Assumed)
    "fablabkhairpur":"Asia", # Pakistan
    "chaihuo":"Asia", # China (Assumed)
    "fablabulb":"Europe", # Belgium (Assumed)
    "esne":"Europe", # Spain (Assumed)
    "ulima":"South America", # Peru
    "fablabseoulinnovation":"Asia", # South Korea
    "benfica":"Europe", # Portugal (Assumed)
    "fablabmadridceu":"Europe", # Spain
    "chandigarh":"Asia", # India
    "jubail":"Asia", # Saudi Arabia
    "ningbo":"Asia", # China
    "fablabwgtn":"Oceania" # New Zealand
}

grouped_lab_names = [
    ['aachen', 'fablabaachen'],
    ['aalto', 'fablabaalto'],
    ['agrilab'],
    ['akgec', 'fablabakgec'],
    ['akureyri'],
    ['algarve', 'farmlabalgarve'],
    ['bahrain', 'fablabbahrain'],
    ['bangalore'],
    ['barcelona'],
    ['benfica'],
    ['berytech', 'fablabberytech'],
    ['bhubaneswar'],
    ['bhutan'],
    ['seoul', 'fablabseoul', 'fablabseoulinnovation', 'boldseoul', 'seoulinnovation'],
    ['bottrop', 'fablabbottrop'],
    ['brighton', 'fablabbrighton'],
    ['cept', 'fablabcept'],
    ['chaihuo'],
    ['chandigarh'],
    ['charlotte', 'fablabcharlottelatin'],
    ['cidi'],
    ['cit'],
    ['ciudadmexico'],
    ['cpcc'],
    ['crunchlab'],
    ['dassault', 'fablabdassault'],
    ['deusto', 'falabdeusto'],
    ['dhahran'],
    ['digiscope', 'fablabdigiscope'],
    ['dilijan'],
    ['ecae'],
    ['echofab', 'fablabechofab'],
    ['ecostudio', 'fablabecostudio'],
    ['egypt', 'fablabegypt'],
    ['energylab'],
    ['esan', 'fablabesan'],
    ['esne'],
    ['fablabamsterdam'],
    ['fablabat3flo'],
    ['fablabbeijing'],
    ['fablabfacens'],
    ['fablabfct'],
    ['fablabgearbox'],
    ['fablabincitefocus'],
    ['fablabirbid', 'irbid'],
    ['fablabisafjorour', 'isafjordur'],
    ['fablabkamakura', 'kamakura'],
    ['fablabkamplintfort', 'kamplintfort'],
    ['fablabkhairpur', 'khairpur'],
    ['fablabkochi', 'kochi'],
    ['fablabkromlaboro'],
    ['fablablccc', 'lccc'],
    ['fablableon', 'leon'],
    ['fablabmadridceu'],
    ['fablabmexico', 'ciudadmexico'],
    ['fablaberfindergarden'],
    ['fablabodessa'],
    ['fablabopendot', 'opendot'],
    ['fablaboshanghai', 'oshanghai'],
    ['fablaboulu', 'oulu'],
    ['fablabpuebla', 'puebla'],
    ['fablabreykjavik', 'reykjavik'],
    ['fablabrwanda', 'rwanda'],
    ['fablabsantiago'],
    ['fablabsiena', 'santachiara'],
    ['fablabsocom'],
    ['fablabsorbonne', 'sorbonne'],
    ['fablabspinderihallerne'],
    ['fablabszoil', 'szoil'],
    ['fablabtechworks', 'techworks'],
    ['fablabtecsup', 'tecsup', 'tecsupaqp'],
    ['fablabtembisa'],
    ['fablabtrivandrum', 'trivandrum'],
    ['fablabuae', 'uae'],
    ['fablabulb', 'ulb'],
    ['fablabutec', 'utec'],
    ['fablabvigyanasharm', 'vigyanashram'],
    ['fablabwgtn'],
    ['fablabyachay'],
    ['fablabyucatan', 'yucatan'],
    ['fablabzoi', 'zoi'],
    ['falabvestmannaeyjar', 'vestmannaeyjar'],
    ['fct'],
    ['formshop'],
    ['hkispace'],
    ['ied'],
    ['incitefocus'],
    ['ingegno'],
    ['inphb'],
    ['insper'],
    ['ioannina'],
    ['jubail'],
    ['kannai'],
    ['kaust'],
    ['keolab'],
    ['kitakagaya'],
    ['lakazlab'],
    ['lamachinerie'],
    ['libya'],
    ['lima'],
    ['napoli'],
    ['newcairo'],
    ['ningbo'],
    ['plusx'],
    ['polytech'],
    ['qbic'],
    ['riidl'],
    ['sedi'],
    ['singapore'],
    ['stjude'],
    ['taipei'],
    ['talents'],
    ['tianhelab'],
    ['tinkerers'],
    ['twarda'],
    ['ucal'],
    ['ucontinental'],
    ['uemadrid'],
    ['ulima'],
    ['vancouver'],
    ['waag'],
    ['wheaton'],
    ['winam']
]

def format_lab_group(lab_group):
    return "/".join(lab_group)

def get_continent(lab_group):
    for lab_name in lab_group:
        if lab_name in labs_by_continent:
            return labs_by_continent[lab_name]
    raise Exception("Lab Not Found")

def node_is_lab(node_id, lab_sort, year_sort):
    url = node_id.split(";")[1]

    lab = url.split("/")[5]

    if year_sort == True:
        year = True
    else:
        year = url.split("/")[3]

    lab_group_current = None
    for lab_group in grouped_lab_names:
        if lab in lab_group:
            lab_group_current = lab_group
            break  
    else:
        raise Exception("Lab Not Found")
    if people_per_lab[format_lab_group(lab_group_current)] < MIN_STUDENTS:
        return False

    return (lab.lower() in lab_sort) and (year or (year in year_sort))

with open("final_data.json", "rb") as file:
    final_data = json.load(file)

people_per_lab = {}

for lab_group in grouped_lab_names:
    formatted = format_lab_group(lab_group)
    people_per_lab[formatted] = 0
for student in final_data['nodes']:
    lab = student['id'].split("/")[5]
    lab_group_name = None
    for lab_group in grouped_lab_names:
        if lab in lab_group:
            lab_group_name = format_lab_group(lab_group)
            break
    else:
        print(lab)
        raise Exception("Lab Not Found")
    people_per_lab[lab_group_name] += 1

densities = {'lab':[], 'density':[], 'geography':[]}

for lab_group in grouped_lab_names:
    if people_per_lab[format_lab_group(lab_group)] < MIN_STUDENTS:
        continue
    G = nx.DiGraph()

    students = []

    LAB = lab_group
    YEAR = True

    # Add nodes to the graph
    for node in final_data["nodes"]:
        students.append(node["id"])
        if not node_is_lab(node["id"], LAB, YEAR):
            continue
        G.add_node(node["id"])

    # Add edges (links) to the graph
    for link in final_data["links"]:
        if (not node_is_lab(link["source"], LAB, YEAR)) or (not node_is_lab(link["target"], LAB, YEAR)):
            continue
        G.add_edge(link["source"], link["target"], weight=link["value"], topic=link["topic"])

    # Calculate density
    density = nx.density(G)
    densities['lab'].append(format_lab_group(lab_group))
    densities['density'].append(density)
    densities['geography'].append(get_continent(lab_group))

df = pd.DataFrame(data=densities)
df.to_csv(f"density_by_lab_minimum_5_students.csv")