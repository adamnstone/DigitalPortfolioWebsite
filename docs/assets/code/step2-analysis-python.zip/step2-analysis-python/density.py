import pandas as pd
import pickle, json
import networkx as nx

with open("final_data.json", "rb") as file:
    final_data = json.load(file)

G = nx.DiGraph()

# Add nodes to the graph
for node in final_data["nodes"]:
    G.add_node(node["id"])

# Add edges (links) to the graph
for link in final_data["links"]:
    G.add_edge(link["source"], link["target"], weight=link["value"], topic=link["topic"])

# Calculate density
density = nx.density(G)

with open("density.obj","wb") as file:
    pickle.dump(density, file)

print(density)