import pandas as pd
import pickle, json
import networkx as nx

TOPICS = [
    "Computer-Aided Design",
    "Computer-Controlled Cutting",
    "Embedded Programing",
    "3D Scanning and Printing",
    "Electronics Design",
    "Computer-Controlled Machining",
    "Electronics Production",
    "Mechanical Design, Machine Design",
    "Input Devices",
    "Moulding and Casting",
    "Output Devices",
    "Embedded Networking and Communications",
    "Interface and Application Programming",
    "Wildcard Week",
    "Applications and Implications",
    "Invention, Intellectual Property and Business Models",
    "Final Project"
]

with open("final_data.json", "rb") as file:
    final_data = json.load(file)

for topic in TOPICS:
    G = nx.DiGraph()

    # Add nodes to the graph
    for node in final_data["nodes"]:
        G.add_node(node["id"])

    # Add edges (links) to the graph
    for link in final_data["links"]:
        if link["topic"] != topic:
            continue
        G.add_edge(link["source"], link["target"], weight=link["value"], topic=link["topic"])

    # Calculate degree centrality
    degree_centrality = nx.degree_centrality(G)

    table_data = {"student":[],"degree_centrality":[]}

    for student in list(degree_centrality.keys()):
        table_data["student"].append(student)
        table_data["degree_centrality"].append(degree_centrality[student])

    df = pd.DataFrame(data=table_data)
    df.to_csv(f"in_degree_centrality_topic_{topic.replace(' ','_')}_all_labs_years.csv")