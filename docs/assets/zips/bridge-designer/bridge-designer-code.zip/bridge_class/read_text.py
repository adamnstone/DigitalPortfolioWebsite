import time
import cv2
import mss
import numpy
import pytesseract

pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'

def scan_text(mon):
    with mss.mss() as sct:
        im = numpy.asarray(sct.grab(mon))
        text = pytesseract.image_to_string(im)

        cv2.imshow('Image', im)
        if cv2.waitKey(25) & 0xFF == ord('q'):
            cv2.destroyAllWindows()
        return text