import pandas as pd
import math, pickle
from bridge_settings import CURRENT_SETTING
from time import sleep
from bridge_class import Bridge, MATERIAL_POS, NUM_MEMBER_MATERIAL_OPTIONS, TYPE_POS, NUM_MEMBER_TYPE_OPTIONS, SIZE_POS, NUM_MEMBER_WIDTH_OPTIONS
from bridge_settings import CURRENT_SETTING

SIZES = [(30,2),(35,2),(40,2),(45,2),(50,2),(55,2),(60,3),(65,3),(70,3),(75,3),(80,4),(90,4),(100,5),(110,5),(120,6),(130,6),(140,7),(150,7),(160,8),(170,8),(180,9),(190,9),(200,10),(220,11),(240,12),(260,13),(280,14),(300,15),(320,16),(340,17),(360,18),(400,20),(500,25)]
MATERIALS = ["CS", "HSS", "QTS"]
TYPES = ["Bar", "Tube"]

csv = pd.read_csv(CURRENT_SETTING['minimums_csv'], index_col="#")

# load forces spreadsheet collected from Bridge Designer
compression_force = csv['Compression Force']
tension_force = csv['Tension Force']

# return load * Factor of Safety
def get_load(member_id):
    return (compression_force[member_id]*1.01, tension_force[member_id]*1.01)

# get cross section area of a member
def get_cross_section_area(member):
    s = member[2][0]/1000
    inn = member[2][1]/1000
    
    if member[1] == "Bar":
        return s**2
    else:
        return (s**2) - ((s - (2*inn)) ** 2)

# return member length
def get_mem_length(m_id):
    return CURRENT_SETTING['strength_data'](m_id,MEMBER_DATA)[1]

# load member data
MEMBER_DATA = []
for filename in CURRENT_SETTING['strength_data_files']:
    with open(filename,'rb') as file:
        MEMBER_DATA.append(pickle.load(file))

# get maximum load for a member
def get_maximum_load(member, m_id):
    sizes_index = -1
    for i,size in enumerate(SIZES):
        if size[0] == member[2][0] and size[1] == member[2][1]:
            sizes_index = i
            break
    return CURRENT_SETTING['strength_data'](m_id,MEMBER_DATA)[0][MATERIALS.index(member[0])][TYPES.index(member[1])][sizes_index]

# calculate bridge price
def get_price(bridge):
    num_unique_types = 0
    uniques = []
    for member in bridge:
        for u in uniques:
            if u[0] == member[0] and u[1] == member[1] and u[2][0] == member[2][0]:
                break
        else:
            uniques.append(member)
    num_unique_types = len(uniques)
    total_cost = CURRENT_SETTING['fixed_cost'] + (1000*num_unique_types)
    for i, member in enumerate(bridge):
        kgs = (7850 * get_cross_section_area(member)*get_mem_length(i+1))
        if member[1] == "Bar":
            total_cost += [4.3,5.6,6][MATERIALS.index(member[0])] * kgs * 2
        else:
            total_cost += [6.3,7,7.7][MATERIALS.index(member[0])] * kgs * 2
    return total_cost

# calculate bridge score
def calculate_score(bridge,log=False): # [(materials, types, sizes), ...]
    for i, member in enumerate(bridge):
        minimum_loads = get_load(i+1)
        maximum_loads = get_maximum_load(member, i+1)
        if log:
            print("MIN", minimum_loads, "MAX", maximum_loads)
            sleep(0.1)
        # score 0 if bridge failed
        if maximum_loads is None:
            return 0
        if minimum_loads[0] > maximum_loads[0] or minimum_loads[1] > maximum_loads[1]:
            return 0
    return 1/get_price(bridge) # lower price = higher score

# put bridge into Bridge Designer program
def enact_bridge(bridge_):
    bridge = [_ for _ in bridge_]
    b = Bridge(CURRENT_SETTING['num_members'], MATERIAL_POS, NUM_MEMBER_MATERIAL_OPTIONS, TYPE_POS, NUM_MEMBER_TYPE_OPTIONS, SIZE_POS, NUM_MEMBER_WIDTH_OPTIONS)
    _bridge = []
    for i,member in enumerate(bridge):
        sizes_index = -1
        for i,size in enumerate(SIZES):
            if size[0] == member[2][0] and size[1] == member[2][1]:
                sizes_index = i
                break
        _bridge.append((member[0],member[1],member[2],sizes_index))
    b.initialize_members(member_list=[(MATERIALS.index(x[0])+1, TYPES.index(x[1])+1, x[3]+1) for x in _bridge])
    b.enact_members()