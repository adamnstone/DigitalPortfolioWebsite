import read_text
from time import sleep
import pyautogui as pg
from tkinter import Tk
import pickle

# three seconds after starting program to open google sheets, then West Point Bridge Designer (so that alt+tab goes between the pages)
sleep(3)

class BridgeMember(object):
    def __init__(self, id, mouse_pos, material_option_pos, num_material_options, type_option_pos, num_type_options, size_option_pos, num_size_options):
        self.id = id
        self.mouse_pos = mouse_pos
        self.material = None
        self.size = None
        self._type = None
        self.num_material_options = num_material_options
        self.num_type_options = num_type_options
        self.num_size_options = num_size_options
        self.material_option_pos = material_option_pos
        self.type_option_pos = type_option_pos
        self.size_option_pos = size_option_pos

    def set_material(self, material):
        self.material = material

    def set_type(self, _type):
        self._type = _type

    def set_size(self, size):
        self.size = size

    def enact_member(self, m, t, s):

        f(self.material_option_pos)
        sleep(0.1)
        pg.press("up", presses=self.num_material_options, interval=0.01)
        pg.press("down", presses=m, interval=0.01)
        pg.press("enter")

        pg.press("tab")
        pg.press("up", presses=self.num_type_options, interval=0.01)
        pg.press("down", presses=t, interval=0.01)
        pg.press("enter")

        pg.press("tab")
        pg.press("up", presses=self.num_size_options, interval=0.01)
        pg.press("down", presses=s, interval=0.01)
        pg.press("enter")

# use get_pos.py to find these coordinates
excel_comp = (1095,1195)
excel_ten = (1545,1191)
excel_pst = (129,447)
copy_to_clipboard = (1320,940)
TEST_POS = [174, 80]
STOP_TEST_POS = [146, 78]
report_tab = (238,47)
report_but = (254,101)
close = (1535,942)
bar = (846,399)

MATERIAL_POS = [186, 121]
def f(p):
    pg.moveTo(p[0],p[1],0.2)
    pg.click()

# copy
def c():
    data = Tk().clipboard_get()
    return data

# transfer the bridge data into excel
def do_bridge():
    f(STOP_TEST_POS)
    sleep(0.5)
    f(report_tab)
    f(report_but)
    f(copy_to_clipboard)
    f(close)
    pg.keyDown("alt")
    pg.press("tab")
    pg.keyUp("alt")
    f(excel_pst)
    pg.keyDown("ctrl")
    pg.press("v")
    pg.keyUp("ctrl")
    sleep(1)
    f(excel_ten)
    pg.keyDown("ctrl")
    pg.press("c")
    pg.keyUp("ctrl")
    sleep(0.5)
    ten = float(c().strip())
    f(excel_comp)
    pg.keyDown("ctrl")
    pg.press("c")
    pg.keyUp("ctrl")
    sleep(0.5)
    com = float(c().strip())
    pg.keyDown("alt")
    pg.press("tab")
    pg.keyUp("alt")
    return(com,ten)

# all settings options
SIZES = [(30,2),(35,2),(40,2),(45,2),(50,2),(55,2),(60,3),(65,3),(70,3),(75,3),(80,4),(90,4),(100,5),(110,5),(120,6),(130,6),(140,7),(150,7),(160,8),(170,8),(180,9),(190,9),(200,10),(220,11),(240,12),(260,13),(280,14),(300,15),(320,16),(340,17),(360,18),(400,20),(500,25)]
MATERIALS = ["CS", "HSS", "QTS"]
TYPES = ["Bar", "Tube"]

# boxes if the bridge fails the "slenderness test" and gets a store of zero (edge case)
CLOSE_BOX = {'top': 830, 'left': 1251, 'width': 1306-1251, 'height': 841-826}
SLENDERNESS_BOX = {'top': 449, 'left': 833, 'width': 1321-833, 'height': 485-449}

DATA = [[[]]]
for i,m in enumerate(MATERIALS):
    for j,t in enumerate(TYPES):
        for k,s in enumerate(SIZES):
            b = BridgeMember(0, MATERIAL_POS, 3, None, 2, None, len(SIZES))
            DATA[i][j].append(None)
            f(bar)
            b.enact_member(i,j,k)
            f(TEST_POS)
            sleep(1)
            print(read_text.scan_text(SLENDERNESS_BOX).lower().strip())
            slenderness_failed = read_text.scan_text(SLENDERNESS_BOX).lower().strip() in ["a member fails the slenderness test.","a mambhar faile tha clandarnacc tact"]
            if slenderness_failed:
                coor = [CLOSE_BOX['left'] + (CLOSE_BOX['width']/2), CLOSE_BOX['top'] + (CLOSE_BOX['height']/2)]
                f(coor)
            else:
                DATA[i][j][k] = do_bridge()
        DATA[i].append([])
    DATA.append([[]])

# store the data in a pickled file - the name of the file is arbitrary
with open("MEMBER_2_24.obj", "wb") as file:
    pickle.dump(DATA,file)