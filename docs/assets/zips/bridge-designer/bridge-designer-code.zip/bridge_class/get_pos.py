import pyautogui as pg
import time

time.sleep(2)
print(pg.position())