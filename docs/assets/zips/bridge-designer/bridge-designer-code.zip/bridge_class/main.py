import random, time, pickle
from bridge_utilities import calculate_score, MATERIALS, SIZES, TYPES, get_price, enact_bridge
import matplotlib.pyplot as plt
import matplotlib as matplt
from bridge_settings import CURRENT_SETTING, INITIALIZED_BRIDGE
import pandas as pd

# Function to initialize a population
def initialize_population(population_size):
    population = []
    for _ in range(population_size):
        if INITIALIZED_BRIDGE is None:
            bridge = [(random.choice(MATERIALS), random.choice(TYPES), random.choice(SIZES[14:])) for _ in range(CURRENT_SETTING['num_members'])]
        else:
            
            df = pd.read_csv(INITIALIZED_BRIDGE)
            bridge=[(r['Member ID'], r['Material Type'], [x for x in SIZES if r['Type']== x[0]][0]) for r in [df.iloc[_] for _ in range(CURRENT_SETTING['num_members'])]] 
        population.append(bridge)
    return population

bridge_mutation_counter = 0

# Function to mutate a bridge
def mutate(bridge):
    global bridge_mutation_counter
    mutated_bridge = bridge[:]
    first = True
    r = random.random()
    i = 0
    while i < bridge_mutation_counter % 30:
        i += 1
        first = False
        member_to_mutate = random.randint(0, CURRENT_SETTING['num_members']-1)
        attribute_to_mutate = random.choice(["material", "type", "size"])
        if attribute_to_mutate == "material":
            mutated_bridge[member_to_mutate] = (random.choice(MATERIALS), bridge[member_to_mutate][1], bridge[member_to_mutate][2])
        elif attribute_to_mutate == "type":
            mutated_bridge[member_to_mutate] = (bridge[member_to_mutate][0], random.choice(TYPES), bridge[member_to_mutate][2])
        else:
            mutated_bridge[member_to_mutate] = (bridge[member_to_mutate][0], bridge[member_to_mutate][1], random.choice(SIZES))
    bridge_mutation_counter += 1
    return mutated_bridge

# Function to run the evolutionary simulation
def run_evo_sim(population_size, fig,line1, NUM_GENS):
    population = initialize_population(population_size)
    generation = 1
    highest_fitness_score_over_gen = [0]*(NUM_GENS)
    while True:
        # Evaluate the population
        fitness_scores = [calculate_score(bridge) for bridge in population]

        # Select the top 50% of the bridges
        top_bridges = [bridge for _, bridge in sorted(zip(fitness_scores, population), key=lambda x: -x[0])][:population_size // 2]
        highest_fitness_score_over_gen[generation] = get_price(top_bridges[0]) 
        
        # Crossover and mutation
        new_population = top_bridges[:]
        while len(new_population) < population_size:
            parent1, parent2 = random.sample(top_bridges, 2)
            crossover_point = random.randint(1, CURRENT_SETTING['num_members']-1)
            child = parent1[:crossover_point] + parent2[crossover_point:]
            mutated_child = mutate(child)
            new_population.append(mutated_child)

        population = new_population 
        global bridge_mutation_counter
        bridge_mutation_counter += 1
        generation += 1
        if generation % 100 == 0:
            print("Generation:", generation, "| Best Score:", max(fitness_scores), " | Price:",[get_price(_) for _ in top_bridges[0:5]])
            line1.set_ydata(highest_fitness_score_over_gen)
            fig.canvas.draw() 
            fig.canvas.flush_events() 
        if generation == NUM_GENS:
            print("FINAL BRIDGE")
            print(top_bridges[0])
            sc = calculate_score(top_bridges[0],log=True)
            print("SCORE:",sc)
            with open(f"bridge_saves/BEST_BRIDGE_fitness_{str(round(get_price(top_bridges[0]),3)).replace('.','-')}.obj", "wb") as file:
                pickle.dump(top_bridges[0],file)
            input("Press enter to enact the bridge:")
            time.sleep(3)
            enact_bridge(top_bridges[0])
            break

if __name__ == "__main__":
    NUM_GENS = 3000
    POP_SIZE = 200
    plt.ion() 
    fig = plt.figure() 
    ax = fig.add_subplot(1,1,1) 
    line1, = ax.plot(list(range(1,NUM_GENS+1)), [0]*NUM_GENS, 'b-')
    ax.set_xlabel("Generation")
    ax.set_ylabel("Price ($)")
    ax.set_title(f"Bridge Price Over {NUM_GENS} Generations of {POP_SIZE} Bridges Each")
    ax.get_xaxis().set_major_formatter(
        matplt.ticker.FuncFormatter(lambda x, p: format(int(x), ',')))
    ax.get_yaxis().set_major_formatter(
        matplt.ticker.FuncFormatter(lambda x, p: format(int(x), ',')))
    plt.ylim(0, 500000)

    # Running the algorithm
    run_evo_sim(POP_SIZE, fig,line1, NUM_GENS)