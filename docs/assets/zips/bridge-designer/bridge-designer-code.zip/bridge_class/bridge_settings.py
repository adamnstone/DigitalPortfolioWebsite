# Bridge Shape 1
def bridge_shape_1_sort_members(x,d):
    if x in [2,5,6,10]:
        return d[3]
    elif x in [1,11,23,24,26,27,32,33,36,37,40,41]:
        return d[4]
    elif x in [3,4,7,9]:
        return d[5]
    elif x in [8]+list(range(12,23)):
        return d[0]
    elif x in [25,34,35,42]:
        return d[2]
    elif x in list(range(28,32))+[38,39]:
        return d[1]
    else:
        print(x)

bridge_shape_1 = {'num_members': 42, 'minimums_csv':'minimums.csv',
                              'strength_data_files':('MEMBER_4.obj','MEMBER_4_47.obj', 'MEMBER_2_24.obj',
                                                     'MEMBER_3_16.obj', 'MEMBER_3_61.obj', 'MEMBER_4_12.obj'),
                                'strength_data':bridge_shape_1_sort_members,
                                'fixed_cost':51700+9000+41800+18400}

# chosen bridge shape
CURRENT_SETTING = bridge_shape_1

# this is where you can specify a starting bridge instead of beginning from random, for example, "BRIDGE_DETAIL_NEW.csv". `None` means start from scratch.
INITIALIZED_BRIDGE = None 