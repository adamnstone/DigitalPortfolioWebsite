import pyautogui as pg
from time import sleep
import numpy as np
from random import random, randint
from bridge_settings import CURRENT_SETTING

# coordinates and settings for Bridge Builder 2016
TYPE_POS = [385, 125]
MATERIAL_POS = [186, 121]
SIZE_POS = [508, 122]
TEST_POS = [174, 80]
STOP_TEST_POS = [146, 78]
NUM_MEMBER_WIDTH_OPTIONS = 33
NUM_MEMBER_TYPE_OPTIONS = 2
NUM_MEMBER_MATERIAL_OPTIONS = 3

# move mouse
current_mouse_pos = None
def move_to(pos):
    global current_mouse_pos
    if current_mouse_pos == pos: return
    current_mouse_pos = pos
    pg.moveTo(pos[0], pos[1], 0.2)

# click from touple
def click(pos):
    pg.click(pos[0], pos[1])

# brige member - used in Bridge class below
class BridgeMember(object):
    def __init__(self, id, material_option_pos, num_material_options, type_option_pos, num_type_options, size_option_pos, num_size_options):
        self.id = id
        self.material = None
        self.size = None
        self._type = None
        self.num_material_options = num_material_options
        self.num_type_options = num_type_options
        self.num_size_options = num_size_options
        self.material_option_pos = material_option_pos
        self.type_option_pos = type_option_pos
        self.size_option_pos = size_option_pos

    def set_material(self, material):
        self.material = material

    def set_type(self, _type):
        self._type = _type

    def set_size(self, size):
        self.size = size

    def enact_member(self):
        move_to(self.material_option_pos)
        click(self.material_option_pos)
        pg.press("tab", presses=23, interval=0.01)
        pg.press("up", presses=CURRENT_SETTING['num_members'], interval=0.01)
        pg.press("down", presses=self.id, interval=0.01)

        move_to(self.material_option_pos)
        click(self.material_option_pos)
        sleep(0.1)
        pg.press("up", presses=self.num_material_options, interval=0.01)
        pg.press("down", presses=self.material-1, interval=0.01)
        pg.press("enter")

        pg.press("tab")
        pg.press("up", presses=self.num_type_options, interval=0.01)
        pg.press("down", presses=self._type-1, interval=0.01)
        pg.press("enter")

        pg.press("tab")
        pg.press("up", presses=self.num_size_options, interval=0.01)
        pg.press("down", presses=self.size-1, interval=0.01)
        pg.press("enter")

    def clamp_values(self):
        self.set_material(np.clip(self.material, 1, self.num_material_options))
        self.set_type(np.clip(self._type, 1, self.num_type_options))
        self.set_size(np.clip(self.size, 1, self.num_size_options))

# for enacting a bridge i.e. entering it into bridge designer via PyAutoGUI
class Bridge(object):
    def __init__(self, num_members, material_option_pos, num_material_options, type_option_pos, num_type_options, size_option_pos, num_size_options):
        self.num_members = num_members
        self.num_material_options = num_material_options
        self.num_type_options = num_type_options
        self.num_size_options = num_size_options
        self.material_option_pos = material_option_pos
        self.type_option_pos = type_option_pos
        self.size_option_pos = size_option_pos
        self.fitness = None
        self.bridge_members = [BridgeMember(i, material_option_pos, num_material_options, type_option_pos, num_type_options, size_option_pos, num_size_options) for i in range(num_members)]
    
    def initialize_members(self, old_bridge=None, member_list=None, random_func=lambda num_opts,current_opt: randint(1, num_opts)):
        if member_list is not None:
            for member_des, member in zip(member_list, self.bridge_members):
                member.set_material(member_des[0])
                member.set_type(member_des[1])
                member.set_size(member_des[2])
                print(member.material,member._type,member.size)
            return
        if old_bridge is None:
            for member in self.bridge_members:
                member.set_material(random_func(self.num_material_options,member.material,member.id))
                member.set_type(random_func(self.num_type_options,member._type,member.id))
                member.set_size(random_func(self.num_size_options,member.size,member.id))
        else:
            for member_new, member_old in zip(self.bridge_members, old_bridge.bridge_members):
                member_new.set_material(member_old.material)
                member_new.set_type(member_old._type)
                member_new.set_size(member_old.size)

    def enact_members(self):
        for member in self.bridge_members:
            member.enact_member()